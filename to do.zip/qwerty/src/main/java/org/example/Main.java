package org.example;

import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try {
            Scanner scanner = new Scanner(System.in);
            DatabaseHandler db = new DatabaseHandler();
            db.initDatabase();

            while (true) {
                System.out.println("\n1. Добавить задачу");
                System.out.println("2. Показать все задачи");
                System.out.println("3. Показать задачу по ID");
                System.out.println("4. Обновить задачу");
                System.out.println("5. Удалить задачу");
                System.out.println("6. Сортировка задач по дате создания");
                System.out.println("7. Поиск задачи по ключевому слову в названии");
                System.out.println("8. Выход");
                System.out.print("Выберите опцию: ");

                int choice = Integer.parseInt(scanner.nextLine());

                switch (choice) {
                    case 1 -> {
                        System.out.print("Название: ");
                        String title = scanner.nextLine();
                        while (title.trim().isEmpty()) {
                            System.out.println("Название не может быть пустым!");
                            System.out.print("Название: ");
                            title = scanner.nextLine();
                        }
                        System.out.print("Описание: ");
                        String desc = scanner.nextLine();
                        Task task = new Task();
                        task.setTitle(title);
                        task.setDescription(desc);
                        db.addTask(task);
                        System.out.println("Задача добавлена.");

                        Logger.log("Добавлена задача: " + task.getTitle());
                    }
                    case 2 -> {
                        List<String> tasks = db.getAllTasks();
                        if ((tasks != null) && (!tasks.isEmpty())){
                            tasks.forEach(System.out::println);
                        } else {
                            System.out.println("\n" + "У вас пока нет задач");
                        }

                        Logger.log("Просмотрены все задачи");
                    }
                    case 3 -> {
                        System.out.print("Введите ID: ");
                        int id = Integer.parseInt(scanner.nextLine());
                        Task task = db.getTaskById(id);
                        if (task != null){
                            System.out.println(task.toString());
                        } else {
                            System.out.println("Задача не найдена");
                        }

                        Logger.log("Получена задача по ID: " + id);
                    }
                    case 4 -> {
                        System.out.print("ID задачи: ");
                        int id = Integer.parseInt(scanner.nextLine());
                        Task task = db.getTaskById(id);
                        if (task != null) {
                            System.out.println("Задача не найдена.");
                            break;
                        }
                        System.out.print("Новое название: ");
                        task.setTitle(scanner.nextLine());
                        while (task.getTitle().isEmpty()) {
                            System.out.println("Название не может быть пустым!");
                            System.out.print("Название: ");
                            task.setTitle(scanner.nextLine());
                        }
                        System.out.print("Новое описание: ");
                        task.setDescription(scanner.nextLine());
                        System.out.print("Новый статус (NEW, IN_PROGRESS, DONE): ");
                        task.setStatus(scanner.nextLine());
                        db.updateTask(task);
                        System.out.println("Задача обновлена.");

                        Logger.log("Обновлена задача: ID " + task.getId());
                    }
                    case 5 -> {
                        System.out.print("ID задачи: ");
                        int id = Integer.parseInt(scanner.nextLine());
                        db.deleteTask(id);
                        System.out.println("Задача удалена.");

                        Logger.log("Удалена задача: ID " + id);
                    }
                    case 6 -> {
                        System.out.println("\n 1. Сортировка по возрастанию \n 2. Сортировка по убыванию");
                        System.out.print("Введите значение: ");
                        int number = Integer.parseInt(scanner.nextLine());

                        String order = switch (number) {
                            case 1 -> "ASC";
                            case 2 -> "DESC";
                            default -> {
                                System.out.println("Некорректный выбор.");
                                yield null;
                            }
                        };

                        if (order != null) {
                            List<Task> sortedTasks = db.getAllTasksSorted(order);
                            if (!sortedTasks.isEmpty()) {
                                sortedTasks.forEach(System.out::println);
                            } else {
                                System.out.println("Список задач пуст.");
                            }
                        }

                        Logger.log("Сортировка задач по дате: " + (order.equals("ASC") ? "по возрастанию"
                                : "по убыванию"));
                    }
                    case 7 -> {
                        System.out.print("Введите ключевое слово для поиска: ");
                        String keyword = scanner.nextLine();
                        List<Task> found = db.searchTasks(keyword);

                        if (!found.isEmpty()) {
                            found.forEach(System.out::println);
                        } else {
                            System.out.println("Ничего не найдено.");
                        }

                        Logger.log("Произведён поиск задачи по названию с использованием ключевого слова "
                                + keyword);
                    }
                    case 8 -> {
                        System.out.println("Выход...");
                        return;
                    }
                    default -> System.out.println("Неверная опция.");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
