package org.example;

import java.sql.Timestamp;

public class Task {
        private int id;
        private String title;
        private String description;
        private String status;
        private Timestamp createdAt;

    @Override
    public String toString() {
        return "\n" + "ID: " + id + "\n" + "Название: " + title + "\n" + "Описание: " + description +
                "\n"+ "Статус: " + status;
    }


    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getStatus() {
        return status;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
}
